# AIP Assistance - installation et configuration RustDesk
# Windows x64 - RustDesk 1.5.0
# Atelier Informatique Potvin

$ErrorActionPreference = 'Stop'

$RustDeskVersion = '1.5.0'
$RustDeskUrl = 'https://github.com/rustdesk/rustdesk/releases/download/1.5.0/rustdesk-1.5.0-x86_64.msi'
$RustDeskSha256 = '624fe792ab1d76b35134dab84bff97a6bcd14043ffd090a2c6a2800f77580495'
$IdServer = 'assistance.atelierpotvin.ca'
$RelayServer = 'assistance.atelierpotvin.ca:21117'
$PublicKey = 'UarCMbouJ6sx0tVQ4x4y41PMBUv1adjGwkIK6XVH0oY='

function Write-Step([string]$Message) {
    Write-Host "`n[AIP] $Message" -ForegroundColor Cyan
}

function Fail([string]$Message) {
    Write-Host "`n==============================================" -ForegroundColor Red
    Write-Host ' AIP ASSISTANCE - ERREUR' -ForegroundColor Red
    Write-Host "==============================================" -ForegroundColor Red
    Write-Host $Message -ForegroundColor Red
    Write-Host "`nFERMEZ CETTE FENETRE APRES AVOIR NOTE LE MESSAGE." -ForegroundColor Yellow
    Read-Host 'Appuyez sur Entree pour fermer'
    exit 1
}

# Elevation UAC
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
$isAdmin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

if (-not $isAdmin) {
    try {
        $args = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
        Start-Process -FilePath 'powershell.exe' -ArgumentList $args -Verb RunAs
        exit 0
    }
    catch {
        Fail "Les droits administrateur sont necessaires. $($_.Exception.Message)"
    }
}

try {
    $rustdesk = Join-Path $env:ProgramFiles 'RustDesk\RustDesk.exe'
    $tempMsi = Join-Path $env:TEMP "rustdesk-$RustDeskVersion-x86_64.msi"

    if (Test-Path $rustdesk) {
        Write-Step 'RustDesk est deja installe - installation ignoree.'
        $installedVersion = (Get-Item $rustdesk).VersionInfo.FileVersion
        if ($installedVersion) {
            Write-Host "[AIP] Version detectee : $installedVersion"
        }
    }
    else {
        Write-Step 'Telechargement du client officiel RustDesk...'
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

        if (Test-Path $tempMsi) {
            Remove-Item $tempMsi -Force
        }

        Invoke-WebRequest -UseBasicParsing -Uri $RustDeskUrl -OutFile $tempMsi

        Write-Step 'Verification SHA-256 du fichier officiel...'
        $actualHash = (Get-FileHash -Path $tempMsi -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualHash -ne $RustDeskSha256) {
            Remove-Item $tempMsi -Force -ErrorAction SilentlyContinue
            Fail "Le controle SHA-256 a echoue. Attendu: $RustDeskSha256 / Recu: $actualHash"
        }

        Write-Step 'Installation de RustDesk...'
        $msiArgs = @(
            '/i',
            "`"$tempMsi`"",
            '/qn',
            '/norestart'
        )
        $installProcess = Start-Process -FilePath 'msiexec.exe' -ArgumentList $msiArgs -Wait -PassThru
        if ($installProcess.ExitCode -notin @(0, 3010)) {
            Fail "Windows Installer a retourne le code $($installProcess.ExitCode)."
        }

        $deadline = (Get-Date).AddSeconds(60)
        while (-not (Test-Path $rustdesk) -and (Get-Date) -lt $deadline) {
            Start-Sleep -Seconds 1
        }
        if (-not (Test-Path $rustdesk)) {
            Fail "RustDesk n'a pas ete trouve dans $rustdesk apres l'installation."
        }
    }

    Write-Step 'Configuration du serveur AIP...'
    & $rustdesk --option custom-rendezvous-server $IdServer | Out-Null
    & $rustdesk --option relay-server $RelayServer | Out-Null
    & $rustdesk --option key $PublicKey | Out-Null

    $svc = Get-Service -Name 'RustDesk' -ErrorAction SilentlyContinue
    if ($null -ne $svc) {
        Restart-Service -Name 'RustDesk' -Force
        Start-Sleep -Seconds 3
    }

    Write-Step 'Verification de la configuration appliquee...'
    $actualIdServer = (& $rustdesk --option custom-rendezvous-server | Out-String).Trim()
    $actualRelay = (& $rustdesk --option relay-server | Out-String).Trim()
    $actualKey = (& $rustdesk --option key | Out-String).Trim()
    $clientId = (& $rustdesk --get-id | Out-String).Trim()

    if ($actualIdServer -ne $IdServer) {
        Fail "Serveur ID incorrect apres configuration: '$actualIdServer'"
    }
    if ($actualRelay -ne $RelayServer) {
        Fail "Serveur relais incorrect apres configuration: '$actualRelay'"
    }
    if ($actualKey -ne $PublicKey) {
        Fail 'La cle publique RustDesk ne correspond pas a la cle AIP.'
    }
    if ([string]::IsNullOrWhiteSpace($clientId)) {
        Fail "RustDesk n'a pas retourne d'identifiant client."
    }

    try {
        $shortcutPath = Join-Path $env:PUBLIC 'Desktop\AIP Assistance.lnk'
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = $rustdesk
        $shortcut.WorkingDirectory = Split-Path $rustdesk
        $shortcut.IconLocation = "$rustdesk,0"
        $shortcut.Description = 'Assistance distante - Atelier Informatique Potvin'
        $shortcut.Save()
    }
    catch {
        Write-Host '[AIP] Raccourci bureau non cree; RustDesk reste installe et configure.' -ForegroundColor Yellow
    }

    Remove-Item $tempMsi -Force -ErrorAction SilentlyContinue

    Write-Host "`n==============================================" -ForegroundColor Green
    Write-Host ' AIP ASSISTANCE - TERMINE' -ForegroundColor Green
    Write-Host "==============================================" -ForegroundColor Green
    Write-Host "Serveur : $actualIdServer"
    Write-Host "Relais  : $actualRelay"
    Write-Host "Votre ID: $clientId" -ForegroundColor Yellow
    Write-Host "`nCommuniquez cet ID a Atelier Informatique Potvin." -ForegroundColor White
    Write-Host 'Aucun mot de passe permanent n a ete cree par cet installateur.' -ForegroundColor White

    Write-Step 'Ouverture de RustDesk...'
    Start-Process -FilePath $rustdesk

    Write-Host "`n==============================================" -ForegroundColor Green
    Write-Host ' TERMINE - INSTALLATION REUSSIE' -ForegroundColor Green
    Write-Host ' VOUS POUVEZ FERMER CETTE FENETRE.' -ForegroundColor Green
    Write-Host ' Fermeture automatique dans 3 secondes...' -ForegroundColor DarkGray
    Write-Host "==============================================" -ForegroundColor Green

    # Un petit processus cache ferme cette console par PID.
    # Cela evite les cas ou exit/Stop-Process depuis le processus courant
    # ne ferme pas la fenetre elevee selon l hote PowerShell utilise.
    $consolePid = $PID
    $watchdog = "Start-Sleep -Seconds 3; Stop-Process -Id $consolePid -Force -ErrorAction SilentlyContinue"
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile','-WindowStyle','Hidden','-Command', $watchdog) -WindowStyle Hidden | Out-Null
    exit 0
}
catch {
    Fail $_.Exception.Message
}
