@echo off
setlocal
cd /d "%~dp0"
title AIP Assistance - Installation
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0AIP-Assistance.ps1"
set RC=%ERRORLEVEL%
if not "%RC%"=="0" (
  echo.
  echo L'installation AIP Assistance a retourne le code %RC%.
  pause
)
exit /b %RC%
