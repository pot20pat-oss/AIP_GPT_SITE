#!/bin/bash
set -u

SERVER="assistance.atelierpotvin.ca"
KEY="UarCMbouJ6sx0tVQ4x4y41PMBUv1adjGwkIK6XVH0oY="
RELAY="assistance.atelierpotvin.ca:21117"

ARM_URL="https://github.com/rustdesk/rustdesk/releases/download/1.5.0/rustdesk-1.5.0-aarch64.dmg"
ARM_SHA="3929b0a4321e7d0f561a317059798be882d65decc59681eb77061f8efe56fbf4"
INTEL_URL="https://github.com/rustdesk/rustdesk/releases/download/1.5.0/rustdesk-1.5.0-x86_64.dmg"
INTEL_SHA="1ca3cbfbe7f2bd28b50c93fcd50d4a0b671dc76d18be27cea99d3a65767eb526"

echo
echo "=============================================="
echo " AIP ASSISTANCE - macOS"
echo " Atelier Informatique Potvin"
echo "=============================================="
echo

ARCH="$(uname -m)"
case "$ARCH" in
  arm64)
    DMG_URL="$ARM_URL"
    EXPECTED_SHA="$ARM_SHA"
    ;;
  x86_64)
    DMG_URL="$INTEL_URL"
    EXPECTED_SHA="$INTEL_SHA"
    ;;
  *)
    echo "ERREUR: architecture Mac non prise en charge: $ARCH"
    echo "Fermez cette fenetre apres avoir note le message."
    read -r
    exit 1
    ;;
esac

TMP_DIR="$(mktemp -d)"
DMG_FILE="$TMP_DIR/RustDesk.dmg"
MOUNT_POINT="$TMP_DIR/mount"
mkdir -p "$MOUNT_POINT"

cleanup() {
  hdiutil detach "$MOUNT_POINT" >/dev/null 2>&1 || true
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT

if [ ! -d "/Applications/RustDesk.app" ]; then
  echo "[AIP] Telechargement de RustDesk 1.5.0 pour macOS ($ARCH)..."
  if ! curl -L --fail --progress-bar "$DMG_URL" -o "$DMG_FILE"; then
    echo "ERREUR: impossible de telecharger RustDesk."
    read -r
    exit 1
  fi

  echo "[AIP] Verification SHA-256..."
  ACTUAL_SHA="$(shasum -a 256 "$DMG_FILE" | awk '{print $1}')"
  if [ "$ACTUAL_SHA" != "$EXPECTED_SHA" ]; then
    echo "ERREUR: verification SHA-256 echouee."
    echo "Attendu: $EXPECTED_SHA"
    echo "Recu:    $ACTUAL_SHA"
    read -r
    exit 1
  fi

  echo "[AIP] Installation dans /Applications..."
  if ! hdiutil attach "$DMG_FILE" -nobrowse -mountpoint "$MOUNT_POINT" >/dev/null; then
    echo "ERREUR: impossible de monter l'image RustDesk."
    read -r
    exit 1
  fi

  if [ ! -d "$MOUNT_POINT/RustDesk.app" ]; then
    echo "ERREUR: RustDesk.app introuvable dans l'image."
    read -r
    exit 1
  fi

  sudo rm -rf "/Applications/RustDesk.app"
  if ! sudo cp -R "$MOUNT_POINT/RustDesk.app" "/Applications/RustDesk.app"; then
    echo "ERREUR: copie de RustDesk dans Applications impossible."
    read -r
    exit 1
  fi
else
  echo "[AIP] RustDesk est deja installe - installation ignoree."
fi

RUSTDESK="/Applications/RustDesk.app/Contents/MacOS/RustDesk"
if [ ! -x "$RUSTDESK" ]; then
  echo "ERREUR: executable RustDesk introuvable."
  read -r
  exit 1
fi

echo "[AIP] Ouverture de RustDesk..."
open -a RustDesk
sleep 4

echo "[AIP] Configuration du serveur prive AIP..."
CONFIG="host=$SERVER,key=$KEY,relay=$RELAY,"
if ! sudo "$RUSTDESK" --config "$CONFIG"; then
  echo "ERREUR: RustDesk n'a pas accepte la configuration."
  read -r
  exit 1
fi

sleep 2

HOST_VALUE="$(sudo "$RUSTDESK" --option custom-rendezvous-server 2>/dev/null | tail -n 1 | tr -d '\r')"
KEY_VALUE="$(sudo "$RUSTDESK" --option key 2>/dev/null | tail -n 1 | tr -d '\r')"
RELAY_VALUE="$(sudo "$RUSTDESK" --option relay-server 2>/dev/null | tail -n 1 | tr -d '\r')"
ID_VALUE="$("$RUSTDESK" --get-id 2>/dev/null | tail -n 1 | tr -d '\r')"

echo
echo "Serveur ID : $HOST_VALUE"
echo "Relais     : $RELAY_VALUE"
echo "ID RustDesk: $ID_VALUE"
echo

if [ "$HOST_VALUE" != "$SERVER" ] || [ "$KEY_VALUE" != "$KEY" ]; then
  echo "=============================================="
  echo " AIP ASSISTANCE - ERREUR DE VERIFICATION"
  echo "=============================================="
  echo "La configuration n'a pas pu etre verifiee."
  echo "Fermez cette fenetre apres avoir note le message."
  read -r
  exit 1
fi

open -a RustDesk

echo "=============================================="
echo " TERMINE - INSTALLATION REUSSIE"
echo "=============================================="
echo "Communiquez votre ID RustDesk a Atelier Potvin."
echo "Vous pouvez fermer cette fenetre."
echo
exit 0
